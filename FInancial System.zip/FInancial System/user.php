<?php include 'sys/ini.php';
$pdo = pdo_init();
if (!empty($_SESSION['aid'])) {

    // $url = BASE_URL . 'admin_logout.php';
    // header("Location: $url");
    // header("Location: device_confirmations.php");
} else {

    header("Location: admin.php");
}
include('class/userClass.php');
$userClass = new userClass();
$adminDetails = $userClass->adminDetails($_SESSION['aid']);




// if (isset($_GET['del'])) {
//     @$id = intval($_GET['id']);
//     // echo '<script>alert(' . $id . ')</script>';
//     @$name = $_GET['name'];
//     $query = $pdo->prepare('DELETE FROM smartphone_inventory WHERE carID=?');
//     $query->execute(array($id));
//     $x = $query->fetch(PDO::FETCH_OBJ);
//     @unlink("uploads/" . $name);
// }

if (isset($_POST['delete'])) {
    $ID = $_POST['ID'];

    // var_dump($imgfile);
    // echo '<script>alert(' . $carID . '); alert(' . $imgfile . '); </script>';

    $delete = $pdo->prepare('DELETE FROM users WHERE usersId=:ID');
    $delete->bindParam(":ID", $ID);
    $ok = $delete->execute();


    echo "<meta http-equiv='refresh' content='0'>";
}

if (isset($_POST['add'])) {
    $username = $_POST['addusername'];
    $email = $_POST['addemail'];
    $name = $_POST['addname'];
    $password = $_POST['addpassword'];
    // $hash_password = hash('sha256', $password);
    $add = $pdo->prepare("INSERT INTO users (username,email,password,name) 
        VALUES (:username,:email,:password,:name)");
    $add->bindParam(":username", $username);
    $add->bindParam(":email", $email);
    $add->bindParam(":password", $password);
    $add->bindParam(":name", $name);

    $add->execute();

    // if ($ok) {
    //     echo "Saved to Database";
    // } else {
    //     echo "No saved";
    // }
    echo "<meta http-equiv='refresh' content='0'>";
}


?>
<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory | Spoiler</title>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/car-style.css">

    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/javascript.js"></script>
    <style>
        table {
            margin: 1%;
            width: 98%;
            font-family: arial, sans-serif;
            border-collapse: collapse;

        }



        .selected {
            background-color: #efefef;

        }

        td,
        th {

            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        input[type="checkbox"] {
            transform: scale(0.5, 0.5);

            -webkit-box-shadow: none;
            box-shadow: none;
        }

        .fileUploadInput {
            display: grid;
            grid-gap: 10px;
            position: relative;
            z-index: 1;
            margin-right: 100px;
        }


        .fileUploadInput input {
            position: relative;
            z-index: 1;


            height: 40px;
            border: 1px solid #323262;
            background-color: rgba(0, 0, 0, 0);
            border-radius: 3px;
            font-family: arial, sans-serif;
            font-size: 10pt;
            user-select: none;
            cursor: pointer;
            font-weight: regular;
        }

        .fileUploadInput input[type="file"] {
            padding: 0 gap(m);
        }

        .fileUploadInput input[type="file"]::-webkit-file-upload-button {
            visibility: hidden;
            margin-left: -5px;
            padding: 0;
            height: 40px;
            width: 0;
        }

        .fileUploadInput button {
            position: absolute;
            right: 0;
            bottom: 0;

            width: 40px;
            height: 40px;
            line-height: 0;
            user-select: none;
            color: white;
            background-color: #323262;
            border-radius: 0 3px 3px 0;
            border: none;
            font-family: arial, sans-serif;
            font-size: 1rem;
            font-weight: 800;
        }

        .fileUploadInput button svg {
            width: auto;
            height: 50%;
        }



        @-moz-document url-prefix() {
            .fileUploadInput button {
                display: none
            }
        }
    </style>
    <script>
        $(document).ready(function() {
            $("#table tr").dblclick(function() {
                $(this).addClass('selected').siblings().removeClass('selected');
                $.id = $(this).find('td#ID').html();
                $.username = $(this).find('td#Username').html();

                $.names = $(this).find('td#Names').html();
                $.pass = $(this).find('td#Pass').html();
                $.emai = $(this).find('td#Email').html();
                if($.id.trim()!=''){
                $('input#tID').val($.id);
                $('input#tusername').val($.username);
                $('input#temail').val($.emai);
                $('input#tname').val($.names);
                $('input#tpass').val($.pass);

                $('#exampleModal').modal('show');
            }
            });
        });

        // $('.ok').on('click', function(e) {
        //     alert($("#table tr.selected td:first").html());
        // });
    </script>
</head>

<body class="" style="background-color:#fff">

<?php
    include 'sys/sidebar.php'
    ?>
    <div id="main">
    <?php 
    include 'sys/admin_navbar.php'
     ?>



    <div class="container">



        <?php




if (isset($_POST['update'])) {
    $id = $_POST['ID'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $name = $_POST['name'];
    $password = $_POST['password'];

    $update = $pdo->prepare("UPDATE users SET username=:username, email=:email, name=:name, password=:password WHERE usersId=:id");
    
    $update->bindParam(":username", $username);
    $update->bindParam(":email", $email);
    $update->bindParam(":password", $password);
    $update->bindParam(":name", $name);
    $update->bindParam(":id", $id);

    $update->execute();

    echo "<meta http-equiv='refresh' content='0'>";
}



        ?>

        <br>
        <!-- <hr> -->
        <div class="rounded  p-4 m-2">
            <div class="d-flex row">
                <div class="col-sm-6">
                    <h3>Users</h3>
                </div>
                <div class="col-sm-6">
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn  border-0 btn-primary " data-bs-toggle="modal" data-bs-target="#addModal">
                            <i class="bi bi-plus-lg"></i>
                        </button>
                    </div>
                </div>
            </div>

            <table id="table" class="p-3">

                <tr>

                    <th style="width:80px">ID&emsp;</th>

                    <th>Username</th>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Password</th>


                    <!-- <th> </th> -->

                </tr>

                <?php
                $query = $pdo->prepare("SELECT * FROM users WHERE usersId");
                $query->execute(array());
                $list = $query->fetchAll(PDO::FETCH_OBJ);
                foreach ($list as $bd) { ?>
                    <tr>



                        <td id="ID"><?php echo $bd->usersId; ?></td>
                        <td id="Username"><?php echo $bd->username; ?></td>
                        <td id="Email"><?php echo $bd->email; ?></td>

                        <td id="Names"><?php echo $bd->name; ?></td>
                        <td id="Pass"><?php echo $bd->password; ?></td>


                    </tr>


                <?php }
                ?>

            </table>

        </div>
        <br>



        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-content  p-0">
                        <!-- <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            </div> -->
                        <div class="modal-body">
                            <div class="row p-2">
                                <div class="col-sm-6">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
                                </div>
                                <div class="col-sm-6">
                                    <div class="d-flex justify-content-end w-100">
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                </div>
                            </div>

                            <div class="  p-3">

                                <input type="hidden" class="form-control    bg-white" name="ID" id="tID" readonly />



                                <label class="fieldlabels">Username:</label><br>

                                <input type="text" class="form-control    bg-white" name="username" id="tusername" />
                                <br>
                                <label class="fieldlabels">Email:</label><br>

                                <input type="text" class="form-control    bg-white" name="email" id="temail" />
                                <br>
                                <label class="fieldlabels">Name:</label><br>

                                <input type="text" class="form-control    bg-white" name="name" id="tname" />
                                <br>
                                <label class="fieldlabels">Password:</label><br>


                                <input type="text" class="form-control    bg-white" name="password" id="tpass" />
                            </div>
                            <br>
                            <div class="d-flex justify-content-end w-100">
                                <input type="submit" name="update" id="update" value="Update" class="  btn btn-primary " style="width: 100px;" />
                                <input type="submit" name="delete" id="delete" value="Delete" class="  btn btn-danger " style="margin-left:5px;margin-right:5px;width: 100px;" />
                                <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>


        <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-content">
                        <!-- <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div> -->
                        <div class="modal-body">
                            <div class="row p-2">
                                <div class="col-sm-6">
                                    <h5 class="modal-title" id="exampleModalLabel">Add</h5>
                                </div>
                                <div class="col-sm-6">
                                    <div class="d-flex justify-content-end w-100">
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                </div>
                            </div>
                            <div class="  p-3">

                                <input type="hidden" class="form-control    bg-white" name="ID" id="tID" readonly />



                                <label class="fieldlabels">Username:</label><br>

                                <input type="text" class="form-control    bg-white" name="addusername" id="tusername" />
                                <br>
                                <label class="fieldlabels">Email:</label><br>

                                <input type="text" class="form-control    bg-white" name="addemail" id="temail" />
                                <br>
                                <label class="fieldlabels">Name:</label><br>

                                <input type="text" class="form-control    bg-white" name="addname" id="tname" />
                                <br>
                                <label class="fieldlabels">Password:</label><br>


                                <input type="text" class="form-control    bg-white" name="addpassword" id="tpass" />
                            </div>
                            <br>
                            <div class="d-flex justify-content-end w-100">
                                <input type="submit" name="add" id="insert" value="Add" class="  btn btn-primary " style="width: 100px;margin-right:5px" />
                                <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                            </div>
                        </div>


                    </div>
                </form>
            </div>
        </div></div>
</body>
<script>
    $(document).ready(function() {
        $('#imgs').change(function() {
            $val = $(this).val();
            $val = $val.replace(/^.*[\\\/]/, '');
            $('input#image').val($val);
            // alert($val);

        });
    });
</script>

</html>