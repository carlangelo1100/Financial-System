-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2023 at 04:43 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `legacy_wealth`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `type` varchar(255) NOT NULL,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `amount`, `type`, `sender`, `receiver`, `desc`, `date`) VALUES
(10, 3, 'sent', 'anna123@gmail.com', 'dvineian1239@gmail.com', '', '2023-11-12'),
(12, 200, 'deposit', 'anna123@gmail.com', '', '', '2023-11-12'),
(13, 10, 'sent', 'dvineian1239@gmail.com', 'anna123@gmail.com', '', '2023-11-12'),
(14, 5000, 'deposit', 'dvineian1239@gmail.com', '', '', '2023-11-12'),
(15, 1000, 'sent', 'anna123@gmail.com', 'xian123@gmail.com', '', '2023-11-12'),
(16, 1500, 'sent', 'dvineian1239@gmail.com', 'xian123@gmail.com', '', '2023-11-12'),
(17, 3000, 'deposit', 'dave123@gmail.com', '', '', '2023-11-12'),
(18, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(19, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(20, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(21, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(22, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(23, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(24, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(25, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(26, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(27, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(28, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(29, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(30, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(31, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(32, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(33, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(34, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(35, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(36, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(37, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(38, 1, 'deposit', 'dave123@gmail.com', '', '', '2023-11-13'),
(39, 3500, 'deposit', 'dave1232@gmail.com', '', '', '2023-11-15'),
(40, 1500, 'sent', 'dave1232@gmail.com', 'jhon123@gmail.com', '', '2023-11-15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `usersId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `usersBal` double NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `google_auth_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usersId`, `name`, `usersBal`, `email`, `username`, `password`, `google_auth_code`) VALUES
(7, 'Jhon Smith', 1500, 'jhon123@gmail.com', 'Jhon', 'jhon1234', 'SS2IOMUCCVQDN2YW'),
(8, 'Dave Smith', 2000, 'dave1232@gmail.com', 'Dave', 'dave1234', 'WYCRJ7NLSKMTTUOT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usersId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `usersId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
