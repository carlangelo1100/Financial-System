<?php include 'sys/ini.php';
if (!empty($_SESSION['uid']) && !empty($_SESSION['googleCode'])) {
    $url = 'logout.php';
    header("Location: $url");
    // header("Location: device_confirmations.php");
}
if (empty($_SESSION['uid'])) {
    header("Location: login.php");
}
$errorMsgReg = '';
include('class/userClass.php');
$userClass = new userClass();
if (!empty($_SESSION['uid'])) {
    $userDetails = $userClass->userDetails($_SESSION['uid']);
}
$db = pdo_init();

$_SESSION['status'] = "";
if (isset($_POST['transfer'])) {
    $amount = $_POST['amount'];
    $usersId = $userDetails->usersId;
    $receiver = $_POST['user_email'];
    // Fetch the current balance
    $stmt = $db->prepare("SELECT usersBal FROM users WHERE usersId = :usersId");
    $stmt->bindParam(':usersId', $usersId, PDO::PARAM_INT);
    $stmt->execute();
    $currentBalance = $stmt->fetchColumn();
    // Check if the balance is sufficient
    if ($currentBalance >= $amount) {
        // Calculate the new balance for the sender
        $newBalance = $currentBalance - $amount;

        // Update the sender's balance in the database
        $stmt = $db->prepare("UPDATE users SET usersBal = :newBalance WHERE usersId = :usersId");
        $stmt->bindParam(':newBalance', $newBalance, PDO::PARAM_STR);
        $stmt->bindParam(':usersId', $usersId, PDO::PARAM_INT);
        $stmt->execute();

        // Fetch the current balance of the receiver
        $stmt = $db->prepare("SELECT usersBal FROM users WHERE email = :email");
        $stmt->bindParam(':email', $receiver, PDO::PARAM_STR);
        $stmt->execute();
        $ReceivercurrentBalance = $stmt->fetchColumn();

        // Calculate the new balance for the receiver
        $ReceivernewBalance = $ReceivercurrentBalance + $amount;

        // Update the receiver's balance in the database
        $stmt = $db->prepare("UPDATE users SET usersBal = :newBalance WHERE email = :email");
        $stmt->bindParam(':newBalance', $ReceivernewBalance, PDO::PARAM_STR);
        $stmt->bindParam(':email', $receiver, PDO::PARAM_STR);
        $stmt->execute();

        $type = "sent";
        // Add the Transaction in the database
        $stmt = $db->prepare("INSERT INTO `transaction`(`amount`,`type`,`sender`,`receiver`) 
    VALUES (:amount,:type,:sender,:receiver)");
        $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
        $stmt->bindParam(':type', $type, PDO::PARAM_STR);
        $stmt->bindParam(':sender', $userDetails->email, PDO::PARAM_STR);
        $stmt->bindParam(':receiver', $receiver, PDO::PARAM_STR);

        $stmt->execute();


        $_SESSION['status'] = '<div class="p-4 bg-success text-light round_md">Success</div>';
    } else {
        $_SESSION['status'] = '<div class="p-4 bg-danger text-light round_md">Insufficient balance</div>';
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<!-- <div class="p-3 bg-success">Success</div> -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0">
    <title>Transfer | Legacy Wealth Group </title>

    <link rel=" icon" href="img/icon.png">
    <!-- CDN -->


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/javascript.js"></script>



    <script>
        // Example money number

        const moneyNumber =;

        // Format the number using toLocaleString()
        const formattedMoney = moneyNumber.toLocaleString('en-US');

        // Set the formatted money in the paragraph
        document.getElementById('amount').textContent = `₱ ${formattedMoney}`;
    </script>
</head>

<body>


    <?php
    include 'sys/navbar.php'
        ?>


    <div class="container   pb-5" style="margin-top:100px;margin-bottom:150px">
        <?= $_SESSION['status']; ?>

        <h3>Transfer</h3>
        <div class=" shadow-sm round_md p-4 border ">
            <form action="" method="post">
                <div class="row">
                    <div class="col-sm-6">
                        <label for="">Enter Amount:</label>
                        <input type="text" class="form-control" name="amount">
                    </div>
                    <div class="col-sm-6">
                        <label for="">Transfer To:</label>

                        <select name="user_email" class="form-select">
                            <?php
                            $query = $db->prepare("SELECT * FROM users ");
                            $query->execute();
                            $list = $query->fetchAll(PDO::FETCH_OBJ);

                            foreach ($list as $user) {
                                if ($user->email != $userDetails->email) {

                                    ?>
                                    <option value="<?= $user->email ?>">
                                        <?= $user->email ?>
                                    </option>

                                <?php }
                            } ?>
                        </select>
                    </div>
                </div>


                <br>
                <button class="btn btn-primary " type="submit" name="transfer">Transfer</button>
            </form>
        </div>
    </div>
    <?php include 'sys/footer.php' ?>

</body>


</html>