<?php include 'sys/ini.php';
if (!empty($_SESSION['uid']) && !empty($_SESSION['googleCode'])) {
    $url = 'logout.php';
    header("Location: $url");
    // header("Location: device_confirmations.php");
}
if (empty($_SESSION['uid'])) {
    header("Location: login.php");
}
$errorMsgReg = '';
include('class/userClass.php');
$userClass = new userClass();
if (!empty($_SESSION['uid'])) {
    $userDetails = $userClass->userDetails($_SESSION['uid']);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0">
    <title>Home | Legacy Wealth Group</title>
    <link rel=" icon" href="img/icon.png">
    <!-- CDN -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/javascript.js"></script>


    <style>
        div.horizontal {
            background-color: #f8f9fa;

        }

        div.scroll {
            background-color: #f8f9fa;
            overflow: auto;
            white-space: nowrap;
        }

        div.cont {
            display: inline-block;
            transition: 0.5s;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #f8f9fa;
        }

        div.cont img {
            margin-top: 50px;
            width: 500px;
            transition: 0.5s;
        }

        div.cont img:hover {
            transform: scale(1.15);
            transition: 0.5s;
        }

        div.cont:hover {
            background-color: #f0f1f2;
            border-radius: 8px;
            transition: 0.5s;
            border: 1px solid #ddd;
        }

        div.caption {
            margin-top: 20px;
            margin-left: 20px;
            background-color: #edeff0;

            color: black;
            padding: 20px;
            border-radius: 8px;
        }

        #store {


            margin-top: 10px;
            height: 100vh;
        }

        .round_md {
            border-radius: 10px;
        }
    </style>
</head>

<body>


    <?php
    include 'sys/navbar.php'
    ?>
    

    <div class="container   pt-sm-5" style="margin-top:100px;margin-bottom:150px">

        <div class="row gap-2  justify-content-center">
            <?php if (!empty($userDetails->username)) { ?>
                <div class="col-lg-8">
                    <div class="row">

                        <div class="col-sm-4">
                            <h3 class="m-0">
                                <?= $userDetails->name ?>
                            </h3>
                            <span>
                                <?= $userDetails->email ?>
                            </span>

                        </div>
                        <div class="col-sm-8 ">
                            <div class="col-sm-8 bg-primary p-4 w-100  round_md text-light border  mb-5">

                                <h1 class="fw-bold" id="usersBal">
                                    <?= "₱ " . number_format($userDetails->usersBal, 2, '.', ','); ?>
                                </h1>

                                <span>Balance</span>
                            </div>
                        </div>

                    </div>


                </div>
            <?php } ?>
            <div class="col-lg-8  align-items-center  ">
                <h5 class="">Options </h3>



                    <div class="row p-2  round_md  text-center text-light">
                        <a href="transfer.php" class="options text-white text-decoration-none col-sm-4 p-4 round_md ">

                            <div>
                                <img src="img/money-transfer.png" width="40px" alt="">

                                <h6 class="mt-2">Transfer</h6>
                            </div>
                        </a>
                        <a href="deposit.php" class="options text-white text-decoration-none col-sm-4  p-4 round_md  ">
                            <div class="">
                                <img src="img/money-deposit.png" width="40px" alt="">
                                <h6 class="mt-2">Deposit</h6>
                            </div>
                        </a>
                        <a href="transaction.php"
                            class="options text-white text-decoration-none col-sm-4 p-4 round_md  shadow-sm">

                            <div>
                                <img src="img/money-transaction.png" width="40px" alt="">
                                <h6 class="mt-2">Transactions</h6>
                            </div>
                        </a>
                        <!-- <div class="col-sm-4 bg-primary p-4 round_md border shadow-sm">
                        <img src="img/money-transfer.png" width="50px" alt="">
                        <h5 class="mt-4">About</h5>
                    </div> -->
                    </div>
            </div>
        </div>

    </div>
    <?php include 'sys/footer.php' ?>

</body>
<script>
    // Example money number

</script>

</html>