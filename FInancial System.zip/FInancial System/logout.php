 <?php
    include 'sys/ini.php';
    $session_uid = '';
    $session_googleCode = '';
    $_SESSION['uid'] = '';

    $_SESSION['googleCode'] = '';
    if (empty($session_uid) && empty($_SESSION['uid'])) {
        $url = 'login.php';
        header("Location: $url");
    }
    ?>