<?php include 'sys/ini.php';
if (!empty($_SESSION['uid']) && !empty($_SESSION['googleCode'])) {
    $url = 'logout.php';
    header("Location: $url");
    // header("Location: device_confirmations.php");
}
if (empty($_SESSION['uid'])) {
    header("Location: login.php");
}
$errorMsgReg = '';
include('class/userClass.php');
$userClass = new userClass();
if (!empty($_SESSION['uid'])) {
    $userDetails = $userClass->userDetails($_SESSION['uid']);
}
$db = pdo_init();

$_SESSION['status'] = "";
if (isset($_POST['deposit'])) {
    $amount = $_POST['amount'];
    $usersId = $userDetails->usersId;

    // Fetch the current balance
    $stmt = $db->prepare("SELECT usersBal FROM users WHERE usersId = :usersId");
    $stmt->bindParam(':usersId', $usersId, PDO::PARAM_INT);
    $stmt->execute();
    $currentBalance = $stmt->fetchColumn();

    // Calculate the new balance
    $newBalance = $currentBalance + $amount;

    // Update the usersBal in the database
    $stmt = $db->prepare("UPDATE users SET usersBal = :newBalance WHERE usersId = :usersId");
    $stmt->bindParam(':newBalance', $newBalance, PDO::PARAM_STR);
    $stmt->bindParam(':usersId', $usersId, PDO::PARAM_INT);

    // Execute the update statement
    $stmt->execute();

    $_SESSION['status'] = '<div class="p-4 bg-success text-light round_md">Success</div>';

    // echo '<script type="text/javascript">window.location.href = window.location.href;</script>';
    // echo "Deposit successful! New balance: $newBalance";


}
?>
<!DOCTYPE html>
<html lang="en">
<!-- <div class="p-3 bg-success">Success</div> -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0">
    <title>Transactions | Legacy Wealth Group</title>
    <link rel=" icon" href="img/icon.png">
    <!-- CDN -->


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/javascript.js"></script>



    <script>
        // Example money number

        const moneyNumber =;

        // Format the number using toLocaleString()
        const formattedMoney = moneyNumber.toLocaleString('en-US');

        // Set the formatted money in the paragraph
        document.getElementById('amount').textContent = `₱ ${formattedMoney}`;
    </script>
</head>

<body>


    <?php
    include 'sys/navbar.php'
        ?>


    <div class="container   pb-5" style="margin-top:100px;margin-bottom:100px">
        <div class="row  align-items-center">
            <div class="col-8">
                <h3>Transaction</h3>
            </div>
            <div class="col-4 text-end">
                <?php     $query = $db->prepare("SELECT * FROM transaction WHERE sender = '" . $userDetails->email . "' OR receiver = '" . $userDetails->email . "'  ORDER BY id DESC");
            $query->execute(array());
            $list = $query->fetchAll(PDO::FETCH_OBJ);
            ?>
                <span class=" small"><?=$query->rowCount()?> items</span>
            </div>

        </div>
        <div class=" shadow-sm round_md p-3 border overflow-auto" style="max-height:70vh ">

            <?php
            $query = $db->prepare("SELECT * FROM transaction WHERE sender = '" . $userDetails->email . "' OR receiver = '" . $userDetails->email . "'  ORDER BY id DESC");
            $query->execute(array());
            $list = $query->fetchAll(PDO::FETCH_OBJ);
            if ($query->rowCount() > 0) {

                foreach ($list as $bd) { ?>



                    <div class="border-bottom p-sm-3 ">
                        <div class="row">
                            <div class="col-8 text-truncate">
                                <span class="fs-5 fw-bold">
                                    <?php
                                    if ($bd->sender == $userDetails->email & $bd->type == "sent") {
                                        echo 'Sent: ₱';
                                    } else if ($bd->receiver == $userDetails->email & $bd->type == "sent") {
                                        echo 'Received: ₱';
                                    } else {
                                        echo 'Deposit: ₱';
                                    } ?>
                                </span>
                                <span class="fs-5 fw-bold" id="amount">
                                    <?= number_format($bd->amount, 2, '.', ','); ?>
                                </span>
                            </div>
                            <div class="col-4 text-end">
                                <span class="small">
                                    <?= $bd->date; ?>
                                </span>
                            </div>
                        </div>
                        <?php if ($bd->sender == $userDetails->email & $bd->type == "sent") { ?>
                            <span class="fs-6">
                                <?= "To: " . $bd->receiver; ?>
                            </span>
                        <?php } else if ($bd->receiver == $userDetails->email & $bd->type == "sent") { ?>
                                <span class="fs-6">
                                <?= "From: " . $bd->sender; ?>
                                </span>


                        <?php } ?>


                        <p class="m-0 text-truncate">

                            <?php
                            if ($bd->sender == $userDetails->email & $bd->type == "sent") {
                                echo 'You have sent ₱ ' . number_format($bd->amount, 2, '.', ',') . ' to ' . $bd->receiver;

                            } else if ($bd->receiver == $userDetails->email & $bd->type == "sent") {
                                echo 'You have received ₱ ' . number_format($bd->amount, 2, '.', ',') . ' from ' . $bd->sender;

                            } else {
                                echo 'You have deposited ₱ ' . number_format($bd->amount, 2, '.', ',') . ' in your account.';

                            } ?>

                        </p>



                    </div>






                <?php }
            } else { ?>
                <center>
                    <h6 class="m-0 p-4"> No Transaction Found!</h6>
                </center>
            <?php }
            ?>


        </div>
    </div>
    <?php include 'sys/footer.php' ?>

</body>


</html>