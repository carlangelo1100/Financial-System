 <?php
    include 'sys/ini.php';
    $session_aid = '';
    $session_googleCode = '';
    $_SESSION['aid'] = '';

    $_SESSION['googleCode'] = '';
    if (empty($session_aid) && empty($_SESSION['aid'])) {
        $url = 'admin.php';
        header("Location: $url");
    }
    ?>