<?php include 'sys/ini.php';
if (!empty($_SESSION['uid']) && !empty($_SESSION['googleCode'])) {
    $url = 'logout.php';
    header("Location: $url");
    // header("Location: device_confirmations.php");
}
if (empty($_SESSION['uid'])) {
    header("Location: login.php");
}
$errorMsgReg = '';
include('class/userClass.php');
$userClass = new userClass();
if (!empty($_SESSION['uid'])) {
    $userDetails = $userClass->userDetails($_SESSION['uid']);
}
$db = pdo_init();

$_SESSION['status'] = "";
if (isset($_POST['deposit'])) {
    $amount = $_POST['amount'];
    $usersId = $userDetails->usersId;
    $type = "deposit";
    // $desc = "You have deposited ₱" . number_format($amount, 2, '.', ',') . " in your account.";

    // Fetch the current balance
    $stmt = $db->prepare("SELECT usersBal FROM users WHERE usersId = :usersId");
    $stmt->bindParam(':usersId', $usersId, PDO::PARAM_INT);
    $stmt->execute();
    $currentBalance = $stmt->fetchColumn();

    // Calculate the new balance
    $newBalance = $currentBalance + $amount;

    // Update the usersBal in the database
    $stmt = $db->prepare("UPDATE users SET usersBal = :newBalance WHERE usersId = :usersId");
    $stmt->bindParam(':newBalance', $newBalance, PDO::PARAM_STR);
    $stmt->bindParam(':usersId', $usersId, PDO::PARAM_INT);

    // Execute the update statement
    $stmt->execute();

    // Add the Transaction in the database
    $stmt = $db->prepare("INSERT INTO `transaction`(`amount`,`sender`,`type`) 
    VALUES (:amount,:sender,:type)");
    $stmt->bindParam(':amount', $amount, PDO::PARAM_STR);
    $stmt->bindParam(':sender', $userDetails->email, PDO::PARAM_STR);
    $stmt->bindParam(':type', $type, PDO::PARAM_STR);
    // $stmt->bindParam(':desc', $desc, PDO::PARAM_STR);

    // Execute the add statement
    $stmt->execute();

    $_SESSION['status'] = '<div class="p-4 bg-success text-light round_md">Success</div>';

    // echo '<script type="text/javascript">window.location.href = window.location.href;</script>';
    // echo "Deposit successful! New balance: $newBalance";


}
?>
<!DOCTYPE html>
<html lang="en">
<!-- <div class="p-3 bg-success">Success</div> -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0">
    <title>Deposit | Legacy Wealth Group </title>
    <link rel=" icon" href="img/icon.png">
    <!-- CDN -->


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
        integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/javascript.js"></script>


    <style>
        div.horizontal {
            background-color: #f8f9fa;

        }

        div.scroll {
            background-color: #f8f9fa;
            overflow: auto;
            white-space: nowrap;
        }

        div.cont {
            display: inline-block;
            transition: 0.5s;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #f8f9fa;
        }

        div.cont img {
            margin-top: 50px;
            width: 500px;
            transition: 0.5s;
        }

        div.cont img:hover {
            transform: scale(1.15);
            transition: 0.5s;
        }

        div.cont:hover {
            background-color: #f0f1f2;
            border-radius: 8px;
            transition: 0.5s;
            border: 1px solid #ddd;
        }

        div.caption {
            margin-top: 20px;
            margin-left: 20px;
            background-color: #edeff0;

            color: black;
            padding: 20px;
            border-radius: 8px;
        }

        #store {


            margin-top: 10px;
            height: 100vh;
        }
    </style>
    <script>
        // Example money number
        const moneyNumber = <?= $userDetails->usersBal ?>;

        // Format the number using toLocaleString()
        const formattedMoney = moneyNumber.toLocaleString('en-US');

        // Set the formatted money in the paragraph
        document.getElementById('usersBal').textContent = `₱ ${formattedMoney}`;
    </script>
</head>

<body>


    <?php
    include 'sys/navbar.php'
        ?>


    <div class="container   pb-5" style="margin-top:100px;margin-bottom:150px">

        <form action="" method="post">
            <div class="row gap-2 justify-content-center ">
                <div class="col-sm-6">
                    <?= $_SESSION['status']; ?>

                </div>
                <div class="col-sm-6 p-2 ">
                <h3>Deposit</h3>
                    <div class=" shadow-sm round_md p-4 border">
                    

                        <label for="">Enter Amount:</label>
                        <input type="text" class="form-control" name="amount"><br>
                        <button class="btn btn-primary " type="submit" name="deposit">Deposit</button>
                    </div>
                </div>


            </div>
        </form>
    </div>
    <?php include 'sys/footer.php' ?>

</body>


</html>