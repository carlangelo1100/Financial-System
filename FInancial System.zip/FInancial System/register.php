<?php
include 'sys/ini.php';
if (!empty($_SESSION['uid'])) {
    header("Location: index.php");
}

include('class/userClass.php');
$userClass = new userClass();

require_once 'googleLib/GoogleAuthenticator.php';
$ga = new GoogleAuthenticator();
$secret = $ga->createSecret();

$errorMsgReg = '';
$errorMsgLogin = '';
if (!empty($_POST['loginSubmit'])) {
    $usernameEmail = $_POST['usernameEmail'];
    $password = $_POST['password'];
    if (strlen(trim($usernameEmail)) > 1 && strlen(trim($password)) > 1) {
        $uid = $userClass->userLogin($usernameEmail, $password, $secret);
        if ($uid) {
            $url = 'index.php';
            header("Location: $url");
        } else {
            $errorMsgLogin = "Please check login details.";
        }
    }
}
$uid;
if (!empty($_POST['signupSubmit'])) {

    $username = $_POST['usernameReg'];
    $email = $_POST['emailReg'];
    $password = $_POST['passwordReg'];
    $name = $_POST['nameReg'];



    // $username_check = preg_match('~^[A-Za-z0-9_]{3,20}$~i', $username);
    // $email_check = preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i', $email);
    // $password_check = preg_match('~^[A-Za-z0-9!@#$%^&*()_]{6,20}$~i', $password);

    // if ($username_check && $email_check && $password_check && strlen(trim($name)) > 0) {

    $uid = $userClass->userRegistration($username, $password, $email, $name, $secret);
    if ($uid) {
        $url = 'logout.php';
        header("Location: $url");
        $errorMsgReg = "Success!";
    } else {
        $errorMsgReg = "Username or Email already exits.";

    }
    // } else {
    //     $errorMsgReg = "Enter invalid details.";
    // }
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Log Up | Legacy Wealth Group </title>

    <meta name="viewport" content="width=device-width, minimum-scale=1.0">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <script>
        function onShow() {
            var login = document.getElementById("login");
            var signup = document.getElementById("signup");
            if (login.style.display === "none") {
                login.style.display = "block";
                signup.style.display = "none";
            } else {
                login.style.display = "none";
                signup.style.display = "block";
            }
        }
    </script>
</head>

<body class=" text-dark" style="background-color:#f5f5f5">
    <div class="container" style="margin-top:25px;margin-bottom:0px">
        <div class="row justify-content-center">
            <div class="col-md-6  left align-items-center d-flex">
                <div class=" ">

                    <div class="pb-5 mb-5  ">
                        <h6 class="m-0"> Financial System</h6>
                        <div class="d-flex align-items-end">
                            <h1 class="m-0" style=" font-size: calc(1.5rem + 2.2vw);"> <b>LEGACY WEALTH<span
                                        style="color:#4265a9;">
                                        GROUP</span> </b></h1>
                        </div>


                        <br>



                    </div>



                </div>
            </div>
            <div class="col-md-4 ">


                <div class="">
                    <div class="d-block">
                        <div id="login" class="p-4 shadow-sm border bg-white round_md">


                            <h2 class="pb-2 text-secondary"><b>Sign Up</b></h2>
                            <br>
                            <form method="post" action="" name="signup">


                                <label>Name</label>
                                <input type="text" class="form-control oval" name="nameReg" autocomplete="on" />

                                <label>Email</label>
                                <input type="text" class="form-control oval" name="emailReg" autocomplete="on" />
                                <label>Username</label>
                                <input type="text" class="form-control oval" name="usernameReg" autocomplete="on" />

                                <label>Password</label>
                                <input type="password" class="form-control oval" name="passwordReg" autocomplete="on" />
                                <div class="errorMsg text-danger">
                                    <?php echo $errorMsgReg; ?>
                                </div>
                                <hr>



                                <center>
                                    <input type="submit" id="submit-btn"
                                        class="w-50  btn btn-primary  border-0 bg-primary text-white"
                                        name="signupSubmit" value="Signup">

                                </center>
                            </form>



                        </div>
                        <br>
                        <center>

                            <small>Already have an account? <a class="" href="login.php">Click here</a></small>
                            <br> <small><a class="" href="admin.php">Administrator</a></small>

                        </center>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <?php

    ?>
</body>

</html>