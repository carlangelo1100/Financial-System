<div class=" footer text-light">
    <footer class="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5 my-5 border-top">

        <div class="col ">
            <h5 class="m-0 ms-3"> LEGACY WEALTH GROUP </h5>
            <small>&emsp;Financial System </small>
            
            
        </div>

        <div class="col ">

        </div>

        <div class="col ">
            <h5> </h5>
            <ul class="nav flex-column ms-3 ">
                <li class=" nav-item  mb-2"><a href="index.php" class="fw-normal nav-link p-0 text-white">Home</a></li>
                <li class="nav-item mb-2"><a href="transfer.php" class="fw-normal nav-link p-0 text-white">Transfer</a></li>
                    </ul>
        </div>

        <div class="col ">
            <h5> </h5>
            <ul class="nav flex-column ms-3 ">
            <li class="nav-item  mb-2"><a href="deposit.php" class="fw-normal nav-link p-0 text-white">Deposit</a></li>
                <li class="nav-item mb-2"><a href="transaction.php" class="fw-normal nav-link p-0 text-white">Transactions</a></li>
                    </ul>
        </div>

        <div class="col ">
            <h5> </h5>
            <ul class="nav flex-column ms-3 ">
            <li class="nav-item  mb-2"><a href="logout.php" class="fw-normal nav-link p-0 text-white">Logout</a></li>
                <!-- <li class="nav-item mb-2"><a href="#" class="fw-normal nav-link p-0 text-white">Features</a></li> -->
                </ul>
        </div>
        
    </footer>

    <div class="designer green">
        <p class="text-light"> LEGACY WEALTH GROUP © 2023 · All rights reserved </p>
    </div>
    


</div>