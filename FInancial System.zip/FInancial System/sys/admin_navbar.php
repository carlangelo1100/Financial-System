<nav class="navbar navbar-expand-md navbar-light fw-bold sticky-top  white-f5   " id="nav">

    <div class="d-flex w-100 align-items-center ">
        <button class="btn   " id="opnbtn" type="button" onclick="toggleNav()"><i class="bi h5 bi-list"></i></button>


        <a href="#" class="navbar-brand ms-3 me-5">
            <div class="d-flex align-items-end">

                <h2> <span style="color:#4265a9;"><b>L</span><span style="color:#5277c2;">W</span><span
                        style="color:#5a82d3;">G</span></b></h2>
                
            </div>

        </a>
        <div class="navbar-nav ms-auto">

            <li class=" ">
                <?php
                if (!empty($adminDetails->username)) { ?>

                    <div class="dropdown w-100 p-2 ps-3 ">

                        <button class="btn text-light  ps-3 p-1 bg-primary  align-items-center d-flex toggle" type="button"
                            id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                            style="border-radius:100px">
                            <?= $adminDetails->username; ?><img class="ms-2 bg-white p-1 " width="25" src="./img/user.png"
                                alt="" style="border-radius:100px">
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end round" aria-labelledby="dropdownMenuButton">
                            <li><a class="dropdown-item small" href="admin_logout.php">Logout</a></li>
                        </ul>

                    </div>

                <?php }
                ?>

            </li>
        </div>



    </div>
</nav>