<nav class=" navbar navbar-expand-md navbar-light fw-bold bg-white fixed-top " id="nav" >

    <a href="#" class="navbar-brand ms-3 me-5">
        <div class="d-flex align-items-end">

            <h2> <span style="color:#4265a9;"><b>L</span><span style="color:#5277c2;">W</span><span
                    style="color:#5a82d3;">G</span></b></h2>
            <img height="40" style="margin-bottom:5px;margin-left:0px;transform:rotate(35deg)" src="img/pechai-nobg.png"
                alt="">
        </div>

    </a>
    <button type="button" onclick="onNav()" class="navbar-toggler" data-bs-toggle="collapse"
        data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav  gap-sm-4">

            <a href="index.php"  class="ps-2 pe-2 nav-item nav-link">Home</a>
            <a href="transfer.php" class="ps-2 pe-2  nav-item nav-link">Transfer</a>
            <a href="deposit.php" class="ps-2 pe-2  nav-item nav-link">Deposit</a>
            <a href="transaction.php" class="ps-2 pe-2  nav-item nav-link">Transactions</a>

        </div>
        <div class="navbar-nav ms-auto">

            <li class=" ">
                <?php
                if (!empty($userDetails->username)) { ?>

                    <div class="dropdown w-100 p-2 ps-3 ">

                        <button class="btn text-light  ps-3 p-1 bg-primary  align-items-center d-flex toggle" type="button" id="dropdownMenuButton"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border-radius:100px">
                            <?= $userDetails->username; ?><img class="ms-2 bg-white p-1 " width="25" src="./img/user.png" alt=""style="border-radius:100px">
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end round" aria-labelledby="dropdownMenuButton">
                            <li><a class="dropdown-item small" href="logout.php">Logout</a></li>
                        </ul>

                    </div>

                <?php }
                ?>

            </li>
        </div>
    </div>

</nav>
<script>

    function handleScroll() {
        var navbar = document.getElementById("nav");

        if (window.scrollY > 0) {
            navbar.classList.add("shadow-sm");

        } else {

            navbar.classList.remove("shadow-sm");
        }
    }
    window.addEventListener("scroll", handleScroll);


</script>