<?php
include 'sys/ini.php';
if (!empty($_SESSION['aid'])) {
    header("Location: inventory.php");
}

include('class/userClass.php');
$userClass = new userClass();

require_once 'googleLib/GoogleAuthenticator.php';
$ga = new GoogleAuthenticator();
$secret = $ga->createSecret();

$errorMsgReg = '';
$errorMsgLogin = '';
if (!empty($_POST['loginSubmit'])) {
    $usernameEmail = $_POST['usernameEmail'];
    $password = $_POST['password'];
    if (strlen(trim($usernameEmail)) > 1 && strlen(trim($password)) > 1) {
        $aid = $userClass->adminLogin($usernameEmail, $password, $secret);
        if ($aid) {
            // $url = BASE_URL . 'inventory.php';
            header("Location: dashboard.php?page=dashboard");
        } else {
            $errorMsgLogin = "Please check login details.";
        }
    }
}


?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Administrator | Legacy Wealth Group</title>
    <meta name="viewport" content="width=device-width, minimum-scale=1.0">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <script>
        function onShow() {
            var login = document.getElementById("login");
            var signup = document.getElementById("signup");
            if (login.style.display === "none") {
                login.style.display = "block";
                signup.style.display = "none";
            } else {
                login.style.display = "none";
                signup.style.display = "block";
            }
        }
    </script>
</head>
<body class=" text-dark" style="background-color:#f5f5f5">
    <div class="container" style="margin-top:100px;margin-bottom:80px">
        <div class="row justify-content-center">
            <div class="col-md-6  left align-items-center d-flex">
                <div class=" ">

                    <div class="pb-sm-5 mb-sm-5 ">
                        <h6 class="m-0"> Financial System</h6>
                        <div class="d-flex align-items-end">
                            <h1 class=" m-0" style=" font-size: calc(1.5rem + 2.2vw);"> <b>LEGACY WEALTH<span
                                        style="color:#4265a9;">
                                        GROUP</span> </b></h1>
                        </div>


                        <br>



                    </div>



                </div>
            </div>
            <div class="col-md-4 ">


                <div class="">
                    <div class="d-block">
                        <div id="login" class="p-4 shadow-sm border bg-white round_md">


                            <h2 class="pb-2 text-secondary"><b>Administrator</b></h2>
                            <br>
                            <form method="post" action="" name="login">
                    <label>Username</label>
                    <input type="text" class="form-control oval" name="usernameEmail" autocomplete="off" />
                    <label>Password</label>
                    <input type="password" class="form-control oval" name="password" autocomplete="off" />
                    <div class="errorMsg"><?php echo $errorMsgLogin; ?></div>
                    <hr>
                    <input type="submit" id="submit-btn" class="w-100  btn bg-primary  border-0 mybg " name="loginSubmit" value="Login">

                </form>



                        </div>
                        <br>
                        <center>
                            </center>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php

    ?>
</body>


</html>